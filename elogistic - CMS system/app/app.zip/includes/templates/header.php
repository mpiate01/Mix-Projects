<!DOCTYPE html>
<html>
<head>
	<title>eLogistic - APP</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="/includes/templates/css/normal.css">
	<link rel="stylesheet" type="text/css" href="/includes/templates/css/style.css">
</head>
<body>
	<div id="page">